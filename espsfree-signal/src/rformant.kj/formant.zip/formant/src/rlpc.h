void rlpc(double *d, short *data, short npoles, short ndata, short iterate); 
